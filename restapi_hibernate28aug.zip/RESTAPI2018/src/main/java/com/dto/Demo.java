package com.dto;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Demo {
	private String message;

	public Demo() {
		super();
	}
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Demo(String message) {
		super();
		this.message = message;
	}

	@Override
	public String toString() {
		return "Demo [message=" + message + "]";
	}
	

}
